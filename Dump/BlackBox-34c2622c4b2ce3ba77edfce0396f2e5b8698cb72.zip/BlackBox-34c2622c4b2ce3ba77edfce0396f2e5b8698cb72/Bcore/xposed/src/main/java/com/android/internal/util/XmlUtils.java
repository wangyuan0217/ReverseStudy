package com.android.internal.util;

import org.xmlpull.v1.XmlPullParserException;

import java.io.InputStream;
import java.util.HashMap;

public class XmlUtils {

    public static final HashMap<String, ?> readMapXml(InputStream in) throws XmlPullParserException, java.io.IOException {
        return null;
    }

}
