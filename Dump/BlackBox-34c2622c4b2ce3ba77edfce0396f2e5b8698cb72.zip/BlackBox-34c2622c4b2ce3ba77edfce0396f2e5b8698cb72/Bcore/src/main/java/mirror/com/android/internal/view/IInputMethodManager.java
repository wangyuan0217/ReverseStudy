package mirror.com.android.internal.view;

import mirror.RefClass;

public class IInputMethodManager {
    public static Class<?> TYPE = RefClass.load(IInputMethodManager.class, "com.android.internal.view.IInputMethodManager");
}
