package mirror.android.app.servertransaction;


import mirror.RefClass;
import mirror.RefObject;

public class TopResumedActivityChangeItem {
    public static Class<?> TYPE = RefClass.load(TopResumedActivityChangeItem.class, "android.app.servertransaction.TopResumedActivityChangeItem");
    public static RefObject<Boolean> mOnTop;
}
