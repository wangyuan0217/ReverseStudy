package mirror.android.hardware.display;

import mirror.RefClass;

public class IDisplayManager {
    public static Class<?> TYPE = RefClass.load(IDisplayManager.class, "android.hardware.display.IDisplayManager");
}
