package mirror.android.rms.resource;


import java.util.List;

import mirror.RefClass;
import mirror.RefObject;

public class ReceiverResourceN {
    public static Class<?> TYPE = RefClass.load(ReceiverResourceN.class, "android.rms.resource.ReceiverResource");
    public static RefObject<List<String>> mWhiteList;
}