package mirror.android.rms.resource;


import mirror.RefClass;
import mirror.RefObject;

public class ReceiverResourceM {
    public static Class<?> TYPE = RefClass.load(ReceiverResourceM.class, "android.rms.resource.ReceiverResource");
    public static RefObject<String[]> mWhiteList;
}