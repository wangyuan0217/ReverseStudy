package mirror.android.app;


import mirror.RefClass;
import mirror.RefObject;

public class LoadedApkKitkat {
    public static Class<?> Class = RefClass.load(LoadedApkKitkat.class, "android.app.LoadedApk");
    public static RefObject<Object> mDisplayAdjustments;
}