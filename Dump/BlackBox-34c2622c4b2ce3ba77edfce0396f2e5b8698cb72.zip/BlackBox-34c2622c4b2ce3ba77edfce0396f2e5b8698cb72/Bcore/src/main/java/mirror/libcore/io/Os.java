package mirror.libcore.io;

import mirror.RefClass;

/**
 * @author Lody
 */

public class Os {
    public static Class<?> TYPE = RefClass.load(Os.class, "libcore.io.Os");
}
