package mirror.android.content.pm;

import mirror.RefClass;
import mirror.RefConstructor;

public class PackageUserState {
    public static Class<?> TYPE = RefClass.load(PackageUserState.class, "android.content.pm.PackageUserState");
    public static RefConstructor<Object> ctor;
}