package mirror.android.rms.resource;

import java.util.List;
import java.util.Map;

import mirror.RefClass;
import mirror.RefObject;

public class ReceiverResourceO {
    public static Class<?> TYPE = RefClass.load(ReceiverResourceO.class, "android.rms.resource.ReceiverResource");
    public static RefObject<Map<Integer, List<String>>> mWhiteListMap;
}