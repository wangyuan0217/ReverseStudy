package mirror.com.android.internal.telephony;

import mirror.RefClass;
import mirror.RefStaticInt;

public class PhoneConstantsMtk {
    public static Class<?> TYPE = RefClass.load(PhoneConstantsMtk.class, "com.android.internal.telephony.PhoneConstants");
    public static RefStaticInt GEMINI_SIM_NUM;
}
