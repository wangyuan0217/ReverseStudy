package mirror.java.io;

import mirror.RefClass;
import mirror.RefStaticObject;

/**
 * Created by Milk on 4/9/21.
 * * ∧＿∧
 * (`･ω･∥
 * 丶　つ０
 * しーＪ
 * 此处无Bug
 */
public class File {
    public static Class<?> TYPE = RefClass.load(mirror.java.io.File.class, "java.io.File");
    public static RefStaticObject<Object> fs;
}
