package mirror.java.io;

import mirror.RefClass;

/**
 * Created by Milk on 4/9/21.
 * * ∧＿∧
 * (`･ω･∥
 * 丶　つ０
 * しーＪ
 * 此处无Bug
 */
public class UnixFileSystem {
    public static Class<?> TYPE = RefClass.load(UnixFileSystem.class, "java.io.UnixFileSystem");
}
