package top.niunaijun.jnihook.jni;

/**
 * Created by Milk on 3/7/21.
 * * ∧＿∧
 * (`･ω･∥
 * 丶　つ０
 * しーＪ
 * 此处无Bug
 */
public class JniHook {

    public static native void nativeOffset();

    public static native void nativeOffset2();

}
